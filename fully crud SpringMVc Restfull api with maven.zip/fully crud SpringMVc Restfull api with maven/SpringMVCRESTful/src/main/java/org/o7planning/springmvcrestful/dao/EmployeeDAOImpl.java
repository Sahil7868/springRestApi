package org.o7planning.springmvcrestful.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.o7planning.springmvcrestful.model.Employee;
import org.springframework.stereotype.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

@Repository("employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	public JdbcTemplate jdbcTemplate;

	private static final String insertSql = "INSERT INTO employee (" + "empNo, " + "empName, " +

			"position )" + "VALUES(?,?,?)";

	private static final String updateSql = "UPDATE employee SET empName = ? , position = ? WHERE empNo = ?";
	
	private static final String deleteSql = "DELETE FROM employee WHERE empNo = ?";

	public List<Employee> getMyList() {
		String query = "select * from employee";
		List<Employee> empList = jdbcTemplate.query(query,
				// new Object[] {empid},
				new BeanPropertyRowMapper(Employee.class)); // select
		// jdbcTemplate.update(query); // delete update insert
		return empList;
	}

	public Employee getMyListbyId(String empNo) {
		String sql = "SELECT * FROM employee WHERE empNo = ?";

		Employee name = (Employee) jdbcTemplate.queryForObject(sql, new Object[] { empNo },
				new BeanPropertyRowMapper(Employee.class));

		return name;
	}

	public Employee addemp(Employee em) {

		Object[] params = new Object[] { em.getEmpNo(), em.getEmpName(), em.getPosition() };
		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };

		int row = jdbcTemplate.update(insertSql, params, types);

		return em;
	}

	public Employee updateemp(String empNo, Employee em) {

		Object[] params = { em.getEmpName(), em.getPosition(), empNo };

		int[] types = { Types.VARCHAR, Types.VARCHAR,  Types.VARCHAR };

		int rows = jdbcTemplate.update(updateSql, params, types);

		String sql = "SELECT * FROM employee WHERE empNo = ?";

		Employee name = (Employee) jdbcTemplate.queryForObject(sql, new Object[] { empNo },
				new BeanPropertyRowMapper(Employee.class));

		return name;

	}
	
	public void deleteEmployee(String empNo)
	{
		Object[] params = { empNo };

		int[] types = { Types.VARCHAR};

		int rows = jdbcTemplate.update(deleteSql, params, types);
	}

}