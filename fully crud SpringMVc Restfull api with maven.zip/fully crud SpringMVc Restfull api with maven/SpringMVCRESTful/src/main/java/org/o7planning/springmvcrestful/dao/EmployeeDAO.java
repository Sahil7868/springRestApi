package org.o7planning.springmvcrestful.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
import org.o7planning.springmvcrestful.model.Employee;
import org.springframework.stereotype.Repository;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource; 
 
@Repository("employeeDAO")
public interface EmployeeDAO {
	
	public List<Employee> getMyList();
	public Employee getMyListbyId(String empno);
	
	public Employee addemp(Employee em);
	
	public Employee updateemp(String empNo,Employee em);
	
	public void deleteEmployee(String empNo);
	
	
}