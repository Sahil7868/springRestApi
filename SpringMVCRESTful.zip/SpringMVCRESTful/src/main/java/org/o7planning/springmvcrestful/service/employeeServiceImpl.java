package org.o7planning.springmvcrestful.service;

import java.sql.Types;
import java.util.List;

import org.o7planning.springmvcrestful.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.o7planning.springmvcrestful.dao.EmployeeDAO;

import org.o7planning.springmvcrestful.model.Employee;

@Service
public class employeeServiceImpl implements employeeService {

	EmployeeDAO employeeDAO;

	@Autowired
	public void setUEmployeeDao(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	public List<Employee> getMyList() {

		return employeeDAO.getMyList();

	}

	public Employee getMyListbyId(String empNo) {

		return employeeDAO.getMyListbyId(empNo);

	}

	public Employee addemp(Employee em) {

		return employeeDAO.addemp(em);
	}

	public Employee updateemp(String empNo, Employee em) {

		return employeeDAO.updateemp(empNo, em);

	}

	public void deleteEmployee(String empNo) {

		employeeDAO.deleteEmployee(empNo);

	}

}
