package org.o7planning.springmvcrestful.service;

import java.util.List;

import org.o7planning.springmvcrestful.model.Employee;
import org.springframework.stereotype.Repository;

@Repository("employeeServ")
public interface employeeService {

	public List<Employee> getMyList();

	public Employee getMyListbyId(String empno);

	public Employee addemp(Employee em);

	public Employee updateemp(String empNo, Employee em);

	public void deleteEmployee(String empNo);

}