package org.shopperholics.maven.dao;

import java.util.List;

import org.shopperholics.maven.model.users;
import org.springframework.stereotype.Repository;

@Repository("usersDao")
public interface UsersDao {

	public List<users> getUserList();

	public users getUserListbyId(Integer userId);

	public users addUser(users user);

	public users updateUser(Integer userId, users user);

	public void deleteUser(Integer userId);

	public Boolean IsExistEmail(String email);

}
