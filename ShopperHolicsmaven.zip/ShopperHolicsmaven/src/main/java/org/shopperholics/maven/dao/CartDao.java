package org.shopperholics.maven.dao;

import java.util.List;

import org.shopperholics.maven.model.Cart;
import org.shopperholics.maven.model.ProCart;
import org.springframework.stereotype.Repository;

@Repository("cartDao")
public interface CartDao {

	// public List<Cart> getCategoryList();

	public Boolean updateCart(Integer cartId, Integer qauntity);
	
	public List<ProCart> getCartByEmail(String email);

	public Cart addCart(Cart cart);
	
	public Double getGrandTotal(String email);
	
	public Integer getQantity(Integer cartId);

	public void deleteCart(Integer cartId);
	
	public void deleteCartByEmail(String email);
	
//	public Cart editCart(Integer cartId);

}
