package org.shopperholics.maven.dao;

import java.util.List;

import org.shopperholics.maven.model.Cart;
import org.shopperholics.maven.model.ProCart;
import org.springframework.stereotype.Repository;

@Repository("cartDao")
public interface CartDao {

	// public List<Cart> getCategoryList();

	public List<ProCart> getCartByEmail(String email);

	public Cart addCart(Cart cart);

	// public Category updateCategory(Integer idcategory, Category category);

	public void deleteCart(Integer cartId);

}
