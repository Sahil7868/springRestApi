package org.shopperholics.maven.service;

import java.util.List;
import org.shopperholics.maven.dao.UsersDao;
import org.shopperholics.maven.model.users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImp implements UserService {

	UsersDao userDAO;

	@Autowired
	public void setUserDao(UsersDao userDAO) {
		this.userDAO = userDAO;
	}

	public List<users> getUserList() {

		return userDAO.getUserList();

	}

	public users getUserListbyId(Integer userId) {

		return userDAO.getUserListbyId(userId);
	}

	public users addUser(users user) {

		return userDAO.addUser(user);

	}

	public users updateUser(Integer userId, users user) {

		return userDAO.updateUser(userId, user);
	}

	public void deleteUser(Integer userId) {

		userDAO.deleteUser(userId);
	}
	
	public Boolean IsExistEmail(String email)
	{
		System.out.println("service maa ayoo");
		Boolean data = userDAO.IsExistEmail(email);
		
		return data;
	}

}
