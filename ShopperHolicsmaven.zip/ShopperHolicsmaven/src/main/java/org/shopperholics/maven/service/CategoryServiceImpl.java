package org.shopperholics.maven.service;

import java.util.List;

import org.shopperholics.maven.dao.CategoryDao;
import org.shopperholics.maven.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl implements CategoryService {

	CategoryDao categoryDao;

	@Autowired
	public void setCategoryDao(CategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}

	public List<Category> getCategoryList() {
		return categoryDao.getCategoryList();

	}

	public Category getCategoryListbyId(Integer idcategory) {
		return categoryDao.getCategoryListbyId(idcategory);
	}

	public Category addCategory(Category category) {
		return categoryDao.addCategory(category);
	}

	public Category updateCategory(Integer idcategory, Category category) {
		return categoryDao.updateCategory(idcategory, category);
	}

	public void deleteCategory(Integer idcategory) {

		categoryDao.deleteCategory(idcategory);

	}

}
