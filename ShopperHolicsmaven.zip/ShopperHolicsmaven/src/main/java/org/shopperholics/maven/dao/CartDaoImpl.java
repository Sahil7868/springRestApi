package org.shopperholics.maven.dao;

import java.sql.Types;
import java.util.List;

import org.shopperholics.maven.model.Cart;
import org.shopperholics.maven.model.ProCart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("cartDao")
public class CartDaoImpl implements CartDao{
	
	
	@Autowired
	public JdbcTemplate jdbcTemplate;

	private static final String insertSql = "INSERT INTO  cart (" + " cartId, " + " pid, " + " email, " + " total) "
			+ " VALUES(?,?,?,?) ";
	
	private static final String deleteSql = "DELETE FROM cart WHERE cartId = ?";
	
	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public Cart addCart(Cart cart)
	{
		Object[] params = new Object[] { null, cart.getPid(), cart.getEmail(), cart.getTotal() };

		int[] types = new int[] { Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.DOUBLE };

		int row = jdbcTemplate.update(insertSql, params, types);

		String sql = "SELECT * FROM cart ORDER BY cartId desc limit 1";

		Cart data = (Cart) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(Cart.class));

		return data;
	}
	
	@SuppressWarnings("unused")
	public void deleteCart(Integer cartId)
	{
		Object[] params = { cartId };

		int[] types = { Types.INTEGER };

		int rows = jdbcTemplate.update(deleteSql, params, types);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<ProCart> getCartByEmail(String email)
	{
		String sql = "SELECT c.*, p.sku, p.name from product as p , cart as c WHERE p.pid=c.pid AND c.email = ? ";

		List<ProCart> data = jdbcTemplate.query(sql, new Object[] { email },
				new BeanPropertyRowMapper(ProCart.class));

		return data;
		
	}

}
