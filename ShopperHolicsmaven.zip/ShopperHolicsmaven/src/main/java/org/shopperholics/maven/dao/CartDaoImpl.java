package org.shopperholics.maven.dao;

import java.sql.Types;
import java.util.List;

import org.shopperholics.maven.model.Cart;
import org.shopperholics.maven.model.ProCart;
import org.shopperholics.maven.model.Product;
import org.shopperholics.maven.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("cartDao")
public class CartDaoImpl implements CartDao {

	@Autowired
	public JdbcTemplate jdbcTemplate;

	@Autowired
	private ProductService productService;

	private static final String insertSql = "INSERT INTO  cart (" + " cartId, " + " pid, " + " email, " + " total, "
			+ " qauntity)" + " VALUES(?,?,?,?,?) ";

	private static final String deleteSql = "DELETE FROM cart WHERE cartId = ?";

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public Cart addCart(Cart cart) {

		String productcount = "SELECT count(*) FROM cart WHERE pid = ? AND email = ?";

		int proCount = jdbcTemplate.queryForObject(productcount, new Object[] { cart.getPid(), cart.getEmail() },
				Integer.class);

		if (proCount > 0) {

			String sqldata = "SELECT * FROM cart WHERE pid = ? AND email = ?";

			Cart cartdata = (Cart) jdbcTemplate.queryForObject(sqldata, new Object[] { cart.getPid(), cart.getEmail() },
					new BeanPropertyRowMapper(Cart.class));

			Double grandTotal = cartdata.getTotal() + cart.getTotal();

			Integer Qauntity = cartdata.getQauntity() + cart.getQauntity();

			String updateSql = "UPDATE cart SET total = ?, qauntity = ? WHERE pid = ? AND email = ?";

			Object[] params = new Object[] { grandTotal, Qauntity, cart.getPid(), cart.getEmail() };

			int[] types = new int[] { Types.DOUBLE, Types.INTEGER, Types.INTEGER, Types.VARCHAR };

			int rowupdate = jdbcTemplate.update(updateSql, params, types);

			if (rowupdate > 0) {
				String sqldataa = "SELECT * FROM product WHERE pid = ?";

				Product productdata = (Product) jdbcTemplate.queryForObject(sqldataa, new Object[] { cart.getPid() },
						new BeanPropertyRowMapper(Product.class));

				Integer previousQauntity = productdata.getQuantity();

				Integer PresentQauntity = cart.getQauntity();

				Integer FinalQantity = previousQauntity - PresentQauntity;

				productdata.setQuantity(FinalQantity);

				productService.updateProduct(cart.getPid(), productdata);

			}

			String sqlquery = "SELECT * FROM cart WHERE pid = ? AND email = ?";

			Cart data = (Cart) jdbcTemplate.queryForObject(sqlquery, new Object[] { cart.getPid(), cart.getEmail() },
					new BeanPropertyRowMapper(Cart.class));

			return data;

		} else {

			Object[] params = new Object[] { null, cart.getPid(), cart.getEmail(), cart.getTotal(),
					cart.getQauntity() };

			int[] types = new int[] { Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.DOUBLE, Types.INTEGER };

			int row = jdbcTemplate.update(insertSql, params, types);

			if (row > 0) {

				String sqldata = "SELECT * FROM product WHERE pid = ?";

				Product productdata = (Product) jdbcTemplate.queryForObject(sqldata, new Object[] { cart.getPid() },
						new BeanPropertyRowMapper(Product.class));

				Integer previousQauntity = productdata.getQuantity();

				Integer PresentQauntity = cart.getQauntity();

				Integer FinalQantity = previousQauntity - PresentQauntity;

				productdata.setQuantity(FinalQantity);

				productService.updateProduct(cart.getPid(), productdata);

			}

			String sql = "SELECT * FROM cart ORDER BY cartId desc limit 1";

			Cart data = (Cart) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(Cart.class));

			return data;
		}
	}

	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	public void deleteCart(Integer cartId) {

		String sqlquery = "SELECT * FROM cart WHERE cartId = ?";

		Cart data = (Cart) jdbcTemplate.queryForObject(sqlquery, new Object[] { cartId },
				new BeanPropertyRowMapper(Cart.class));

		String sqldata = "SELECT * FROM product WHERE pid = ?";

		Product productdata = (Product) jdbcTemplate.queryForObject(sqldata, new Object[] { data.getPid() },
				new BeanPropertyRowMapper(Product.class));

		Integer previousQauntity = productdata.getQuantity();

		Integer PresentQauntity = data.getQauntity();

		Integer FinalQantity = previousQauntity + PresentQauntity;

		productdata.setQuantity(FinalQantity);

		productService.updateProduct(data.getPid(), productdata);

		Object[] params = { cartId };

		int[] types = { Types.INTEGER };

		int rows = jdbcTemplate.update(deleteSql, params, types);

	}

	@SuppressWarnings("unused")
	public void deleteCartByEmail(String email) {

		String deleteSql = "DELETE FROM cart WHERE email = ?";

		Object[] params = { email };

		int[] types = { Types.VARCHAR };

		int rows = jdbcTemplate.update(deleteSql, params, types);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<ProCart> getCartByEmail(String email) {
		String sql = "SELECT c.*, p.sku, p.name, p.discountprice from product as p , cart as c WHERE p.pid=c.pid AND c.email = ? ";

		List<ProCart> data = jdbcTemplate.query(sql, new Object[] { email }, new BeanPropertyRowMapper(ProCart.class));

		return data;

	}

	public Double getGrandTotal(String email) {
		String sqll = "SELECT count(*) FROM cart WHERE email = ?";

		int row = jdbcTemplate.queryForObject(sqll, new Object[] { email }, Integer.class);

		if (row > 0) {

			String sql = "SELECT sum(total) from cart where email = ?";

			Double data = jdbcTemplate.queryForObject(sql, new Object[] { email }, Double.class);

			return data;
		} else {
			Double data = (double) -1;

			return data;
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Integer getQantity(Integer cartId) {
		String sqlquery = "SELECT * FROM cart WHERE cartId = ?";

		Cart data = (Cart) jdbcTemplate.queryForObject(sqlquery, new Object[] { cartId },
				new BeanPropertyRowMapper(Cart.class));

		String sqldata = "SELECT * FROM product WHERE pid = ?";

		Product productdata = (Product) jdbcTemplate.queryForObject(sqldata, new Object[] { data.getPid() },
				new BeanPropertyRowMapper(Product.class));

		Integer previousQauntity = productdata.getQuantity();

		Integer PresentQauntity = data.getQauntity();

		Integer FinalQantity = previousQauntity + PresentQauntity;

		return FinalQantity;
	}

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public Boolean updateCart(Integer cartId, Integer qauntity) {
		String sqlquery = "SELECT * FROM cart WHERE cartId = ?";

		Cart data = (Cart) jdbcTemplate.queryForObject(sqlquery, new Object[] { cartId },
				new BeanPropertyRowMapper(Cart.class));

		String sqldata = "SELECT * FROM product WHERE pid = ?";

		Product productdata = (Product) jdbcTemplate.queryForObject(sqldata, new Object[] { data.getPid() },
				new BeanPropertyRowMapper(Product.class));

		Integer previousQauntity = productdata.getQuantity();

		Integer PresentQauntity = data.getQauntity();

		Integer SemiFinalQantity = previousQauntity + PresentQauntity;

		Integer FinalQauntity = SemiFinalQantity - qauntity;

		Double totaly = productdata.getDiscountprice() * qauntity;

		String sqlupdate = "UPDATE cart SET qauntity = ?, total = ? WHERE cartId = ?";

		Object[] params = new Object[] { qauntity, totaly, cartId };

		int[] types = new int[] { Types.INTEGER, Types.DOUBLE, Types.INTEGER };

		int rows = jdbcTemplate.update(sqlupdate, params, types);

		productdata.setQuantity(FinalQauntity);

		productService.updateProduct(data.getPid(), productdata);

		if (rows > 0) {
			return true;
		} else {
			return false;
		}

	}

}
