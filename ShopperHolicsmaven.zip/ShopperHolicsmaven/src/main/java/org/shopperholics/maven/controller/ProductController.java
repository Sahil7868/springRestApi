package org.shopperholics.maven.controller;

import java.util.List;

import org.shopperholics.maven.model.ProCat;
import org.shopperholics.maven.model.Product;
import org.shopperholics.maven.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

	@Autowired
	private ProductService productService;

	@RequestMapping(value = "getallProducts", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<ProCat> getProducts() {
		List<ProCat> list = productService.getProductList();

		return list;
	}

	@RequestMapping(value = "/getProductById/{pid}", method = RequestMethod.GET, 
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Product getProductByid(@PathVariable("pid") Integer pid) {
		return productService.getProductListbyId(pid);
	}

	@RequestMapping(value = "/addProduct", 
			method = RequestMethod.POST, 
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })

	@ResponseBody
	public Product addProduct(@RequestBody Product product) {

		Product data = new Product();
		data = productService.addProduct(product);
		return data;

	}

	@RequestMapping(value = "/updateProduct/{pid}", 
			method = RequestMethod.PUT, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Product updateProduct(@PathVariable("pid") Integer pid, @RequestBody Product product) {

		return productService.updateProduct(pid, product);
	}

	@RequestMapping(value = "/deleteProduct/{pid}", 
			method = RequestMethod.DELETE, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteProduct(@PathVariable("pid") Integer pid) {
		productService.deleteProduct(pid);
	}

}
