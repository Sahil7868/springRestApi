package org.shopperholics.maven.controller;

import java.util.List;

import org.shopperholics.maven.model.ProCat;
import org.shopperholics.maven.model.Product;
import org.shopperholics.maven.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
//import java.io.BufferedOutputStream;  
//import java.io.File;  
//import java.io.FileOutputStream;  
//import javax.servlet.ServletContext;   
//import javax.servlet.http.HttpServletRequest;  
//import javax.servlet.http.HttpServletResponse;  
//import javax.servlet.http.HttpSession;  
//import org.apache.commons.fileupload.disk.DiskFileItemFactory;  
//import org.apache.commons.fileupload.servlet.ServletFileUpload;  
//import org.springframework.stereotype.Controller;  
//import org.springframework.web.bind.annotation.ModelAttribute; 
//import org.springframework.web.bind.annotation.RequestParam;  
//import org.springframework.web.multipart.commons.CommonsMultipartFile;  
//import org.springframework.web.servlet.ModelAndView; 

@RestController
public class ProductController {

	// private static final String UPLOAD_DIRECTORY ="/images";

	@Autowired
	private ProductService productService;

	@RequestMapping(value = "getallProducts", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<ProCat> getProducts() {
		List<ProCat> list = productService.getProductList();

		return list;
	}

	@RequestMapping(value = "/getProductById/{pid}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Product getProductByid(@PathVariable("pid") Integer pid) {
		return productService.getProductListbyId(pid);
	}

	@RequestMapping(value = "/addProduct", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })

	@ResponseBody
	public Product addProduct(@RequestBody Product product) {

		// ServletContext context = session.getServletContext();
		// String path = context.getRealPath(UPLOAD_DIRECTORY);
		// String filename = sku.getOriginalFilename();
		//
		// System.out.println(path+" "+filename);
		//
		// byte[] bytes = sku.getBytes();
		// BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(
		// new File(path + File.separator + filename)));
		// stream.write(bytes);
		// stream.flush();
		// stream.close();
		//
		// //return new ModelAndView("uploadform","filesuccess","File successfully
		// saved!");

		Product data = new Product();
		data = productService.addProduct(product);
		return data;

	}

	@RequestMapping(value = "/updateProduct/{pid}", method = RequestMethod.PUT, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Product updateProduct(@PathVariable("pid") Integer pid, @RequestBody Product product) {

		return productService.updateProduct(pid, product);
	}

	@RequestMapping(value = "/deleteProduct/{pid}", method = RequestMethod.DELETE, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteProduct(@PathVariable("pid") Integer pid) {
		productService.deleteProduct(pid);
	}

}
