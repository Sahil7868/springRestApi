package org.shopperholics.maven.service;

import java.util.List;

import org.shopperholics.maven.model.ProCat;
import org.shopperholics.maven.model.Product;
import org.springframework.stereotype.Repository;

@Repository("productService")
public interface ProductService {
	
	public List<ProCat> getProductList();

	public Product getProductListbyId(Integer pid);

	public Product addProduct(Product product);

	public Product updateProduct(Integer pid, Product product);

	public void deleteProduct(Integer pid);

}
