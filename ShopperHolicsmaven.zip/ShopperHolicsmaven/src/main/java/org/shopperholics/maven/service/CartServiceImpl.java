package org.shopperholics.maven.service;

import java.util.List;

import org.shopperholics.maven.dao.CartDao;
import org.shopperholics.maven.model.Cart;
import org.shopperholics.maven.model.ProCart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartServiceImpl implements CartService {

	CartDao cartDao;

	@Autowired
	public void setCartDao(CartDao cartDao) {
		this.cartDao = cartDao;
	}

	public Cart addCart(Cart cart) {
		return cartDao.addCart(cart);
	}

	public void deleteCart(Integer cartId) {
		cartDao.deleteCart(cartId);
	}
	
	public List<ProCart> getCartByEmail(String email)
	{
		return cartDao.getCartByEmail(email);
	}

}
