package org.shopperholics.maven.model;

public class ProCart {

	private Integer cartId;
	private Integer pid;
	private String email;
	private Double total;
	private String sku;
	private String name;
	
	public ProCart() {}

	public ProCart(Integer cartId, Integer pid, String email, Double total, String sku, String name) {
		
		this.cartId = cartId;
		this.pid = pid;
		this.email = email;
		this.total = total;
		this.sku = sku;
		this.name = name;
	}

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
