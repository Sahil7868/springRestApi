package org.shopperholics.maven.validation;

import org.shopperholics.maven.model.users;

public class UserValidation {
	
	private users user;
	private boolean emailCheck = true;
	
	private boolean emailExist = true;
	
	public boolean isEmailExist() {
		return emailExist;
	}

	public void setEmailExist(boolean emailExist) {
		this.emailExist = emailExist;
	}

	public UserValidation()
	{
		this.user = new users(); 
	}

	public users getUser() {
		return user;
	}

	public void setUser(users user) {
		this.user = user;
	}

	public boolean isEmailCheck() {
		return emailCheck;
	}

	public void setEmailCheck(boolean emailCheck) {
		this.emailCheck = emailCheck;
	}
	
	

}
