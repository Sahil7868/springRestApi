package org.shopperholics.maven.controller;

import java.util.List;

import org.shopperholics.maven.model.Cart;

import org.shopperholics.maven.model.ProCart;
import org.shopperholics.maven.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartController {

	@Autowired
	private CartService cartSerive;

	@RequestMapping(value = "/addCart", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })

	@ResponseBody
	public Cart addCart(@RequestBody Cart cart) {

		Cart data = new Cart();
		data = cartSerive.addCart(cart);
		return data;

	}

	@RequestMapping(value = "/deleteCart/{cartId}", method = RequestMethod.DELETE, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteCart(@PathVariable("cartId") Integer cartId) {
		cartSerive.deleteCart(cartId);
	}
	
	
	@RequestMapping(value = "/deleteCartByEmail/{email}", method = RequestMethod.DELETE, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteCartbyEmail(@PathVariable("email") String email) {
		cartSerive.deleteCartByEmail(email);
	}

	@RequestMapping(value = "/getCartByEmail/{email}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<ProCart> getCartByEmail(@PathVariable("email") String email) {

		List<ProCart> list = cartSerive.getCartByEmail(email);

		return list;
	}

	@RequestMapping(value = "/gettotal/{email}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Double getGrandTotal(@PathVariable("email") String email) {

		Double data = cartSerive.getGrandTotal(email);

		return data;
	}

	@RequestMapping(value = "/getqauntity/{cartId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Integer getQauntity(@PathVariable("cartId") Integer cartId) {

		Integer data = cartSerive.getQantity(cartId);

		return data;
	}

	@RequestMapping(value = "/updateCart/{cartId}/{qauntity}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Boolean updateCart(@PathVariable("cartId") Integer cartId, @PathVariable("qauntity") Integer qauntity) {

		Boolean data = cartSerive.updateCart(cartId, qauntity);

		return data;
	}

}
