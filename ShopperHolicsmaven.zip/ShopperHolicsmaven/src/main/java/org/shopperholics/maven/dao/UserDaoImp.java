package org.shopperholics.maven.dao;

import java.util.List;
import java.sql.Types;

import org.shopperholics.maven.model.users;
import org.springframework.stereotype.Repository;
import java.util.Date;
import java.sql.Timestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

@Repository("usersDao")
public class UserDaoImp implements UsersDao {

	@Autowired
	public JdbcTemplate jdbcTemplate;

	Date date = new Date();
	long time = date.getTime();
	Timestamp ts = new Timestamp(time);

	private static final String insertSql = "INSERT INTO  users (" + " usersid, " + " email, " +

			" firstname, " + " lastname, " + " active, " + " password, " + " role) " + " VALUES(?,?,?,?,?,?,?) ";

	private static final String updateSql = "UPDATE users SET  email = ? , firstname = ? , lastname = ? ,  password = ?  WHERE usersid = ?";

	private static final String deleteSql = "DELETE FROM users WHERE usersid = ?";

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<users> getUserList() {

		String query = "SELECT * from users";
		List<users> list = jdbcTemplate.query(query,

				new BeanPropertyRowMapper(users.class));

		return list;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public users getUserListbyId(Integer userId) {

		String sql = "SELECT * FROM users WHERE usersid = ?";

		users data = (users) jdbcTemplate.queryForObject(sql, new Object[] { userId },
				new BeanPropertyRowMapper(users.class));

		return data;
	}

	@SuppressWarnings({ "unchecked", "unused", "rawtypes" })
	public users addUser(users user) {

		Object[] params = new Object[] { null, user.getEmail(), user.getFirstname(), user.getLastname(),
				user.getActive(), user.getPassword(), user.getRole() };

		int[] types = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TINYINT,
				Types.VARCHAR, Types.TINYINT };

		int row = jdbcTemplate.update(insertSql, params, types);

		String sql = "SELECT * FROM users ORDER BY usersid desc limit 1";

		users data = (users) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(users.class));

		return data;
	}

	@SuppressWarnings({ "unused", "unchecked", "rawtypes" })
	public users updateUser(Integer userId, users user) {

		Object[] params = new Object[] { user.getEmail(), user.getFirstname(), user.getLastname(), user.getPassword(),
				userId };

		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER };

		int rows = jdbcTemplate.update(updateSql, params, types);

		String sql = "SELECT * FROM users WHERE usersid = ?";

		users data = (users) jdbcTemplate.queryForObject(sql, new Object[] { userId },
				new BeanPropertyRowMapper(users.class));

		return data;

	}

	@SuppressWarnings("unused")
	public void deleteUser(Integer userId) {

		Object[] params = { userId };

		int[] types = { Types.INTEGER };

		int rows = jdbcTemplate.update(deleteSql, params, types);
	}

	public Boolean IsExistEmail(String email) {

		String sql = "SELECT count(*) FROM users WHERE email = ?";

		Boolean data = false;

		int row = jdbcTemplate.queryForObject(sql, new Object[] { email }, Integer.class);

		if (row > 0) {
			data = true;
		}

		return data;
	}

}
