package org.shopperholics.maven.model;

public class Cart {
	
	private Integer cartId;
	private Integer pid;
	private String email;
	private Double total;
	private Integer qauntity;
	
	public Cart () {}

	public Cart(Integer cartId, Integer pid, String email, Double total, Integer qauntity) {
		
		this.cartId = cartId;
		this.pid = pid;
		this.email = email;
		this.total = total;
		this.qauntity = qauntity;
	}

	
	public Integer getQauntity() {
		return qauntity;
	}

	public void setQauntity(Integer qauntity) {
		this.qauntity = qauntity;
	}

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}
	
	

}
