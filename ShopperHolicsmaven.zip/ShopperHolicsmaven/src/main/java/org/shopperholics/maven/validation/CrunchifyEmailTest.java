package org.shopperholics.maven.validation;

import java.io.File;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
//import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class CrunchifyEmailTest implements EmailService {

	

	JavaMailSender mailSender;

	@Autowired
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	public void sendmail(String email,String name) throws MessagingException {

		// SimpleMailMessage message = new SimpleMailMessage();

		MimeMessage message = mailSender.createMimeMessage();

		message.setSubject("Welcome " + " " + name + " " + " to bShopperHolics");
		MimeMessageHelper helper;
		helper = new MimeMessageHelper(message, true);
		helper.setTo(email);
		helper.setText(
				"<html><body><h1 style='color:lightgrey;'>Thank You For Choosing bShopperHolics</h1></br></br><img src='cid:identifier1234'></body></html>",
				true);

		FileSystemResource res = new FileSystemResource(new File("C:\\Users\\contractor\\Downloads\\shopping.jfif"));
		helper.addInline("identifier1234", res);

		mailSender.send(message);

	}

}
