package org.shopperholics.maven.service;

import java.util.List;

import org.shopperholics.maven.model.users;
import org.springframework.stereotype.Repository;

@Repository("userService")
public interface UserService {

	public List<users> getUserList();

	public users getUserListbyId(Integer userId);

	public users addUser(users user);

	public users updateUser(Integer userId, users user);

	public void deleteUser(Integer userId);
	
	public Boolean IsExistEmail(String email);

}
