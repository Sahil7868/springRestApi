package org.shopperholics.maven.dao;

import java.sql.Types;
import java.util.List;

import org.shopperholics.maven.model.ProCat;
import org.shopperholics.maven.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public class ProductDaoImpl implements ProductDao {

	@Autowired
	public JdbcTemplate jdbcTemplate;

	private static final String insertSql = "INSERT INTO  product (" + " pid, " + " sku, " +

			" name, " + " description, " + " regularprice, " + " discountprice, " + " quantity, " + " idcategory) "
			+ " VALUES(?,?,?,?,?,?,?,?) ";

	private static final String updateSql = "UPDATE product SET  sku = ? , name = ? , description = ? ,  regularprice = ? , discountprice = ? , quantity = ? , idcategory = ? WHERE pid = ?";

	private static final String deleteSql = "DELETE FROM product WHERE pid = ?";

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ProCat> getProductList() {
		String query = "SELECT p.* , c.categoryname FROM shopperholics.category as c, shopperholics.product as p where p.idcategory=c.idcategory limit 0,6";
		List<ProCat> list = jdbcTemplate.query(query,

				new BeanPropertyRowMapper(ProCat.class));

		return list;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Product getProductListbyId(Integer pid) {
		String sql = "SELECT * FROM product WHERE pid = ?";

		Product data = (Product) jdbcTemplate.queryForObject(sql, new Object[] { pid },
				new BeanPropertyRowMapper(Product.class));

		return data;

	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	public Product addProduct(Product product) {

		Object[] params = new Object[] { null, product.getSku(), product.getName(), product.getDescription(),
				product.getRegularprice(), product.getDiscountprice(), product.getQuantity(), product.getIdcategory() };

		int[] types = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DOUBLE,
				Types.DOUBLE, Types.INTEGER, Types.INTEGER };

		int row = jdbcTemplate.update(insertSql, params, types);

		String sql = "SELECT * FROM product ORDER BY pid desc limit 1";

		Product data = (Product) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(Product.class));

		return data;

	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	public Product updateProduct(Integer pid, Product product) {

		Object[] params = new Object[] { product.getSku(), product.getName(), product.getDescription(),
				product.getRegularprice(), product.getDiscountprice(), product.getQuantity(), product.getIdcategory(), pid };

		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DOUBLE, Types.DOUBLE,
				Types.INTEGER, Types.INTEGER, Types.INTEGER };

		int rows = jdbcTemplate.update(updateSql, params, types);

		String sql = "SELECT * FROM product WHERE pid = ?";

		Product data = (Product) jdbcTemplate.queryForObject(sql, new Object[] { pid },
				new BeanPropertyRowMapper(Product.class));

		return data;

	}

	@SuppressWarnings("unused")
	public void deleteProduct(Integer pid) {

		Object[] params = { pid };

		int[] types = { Types.INTEGER };

		int rows = jdbcTemplate.update(deleteSql, params, types);

	}

}
