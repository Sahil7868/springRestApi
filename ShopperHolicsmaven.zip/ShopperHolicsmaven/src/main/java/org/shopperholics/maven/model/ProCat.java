package org.shopperholics.maven.model;

public class ProCat {

	private Integer idcategory;
	private String categoryname;
	private Integer pid;
	private String sku;
	private String name;
	private String description;
	private Double regularprice;
	private Double discountprice;
	private Integer quantity;

	public ProCat() {
	}

	public ProCat(Integer idcategory, String categoryname, Integer pid, String sku, String name, String description,
			Double regularprice, Double discountprice, Integer quantity) {

		this.idcategory = idcategory;
		this.categoryname = categoryname;
		this.pid = pid;
		this.sku = sku;
		this.name = name;
		this.description = description;
		this.regularprice = regularprice;
		this.discountprice = discountprice;
		this.quantity = quantity;
	}

	public Integer getIdcategory() {
		return idcategory;
	}

	public void setIdcategory(Integer idcategory) {
		this.idcategory = idcategory;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getRegularprice() {
		return regularprice;
	}

	public void setRegularprice(Double regularprice) {
		this.regularprice = regularprice;
	}

	public Double getDiscountprice() {
		return discountprice;
	}

	public void setDiscountprice(Double discountprice) {
		this.discountprice = discountprice;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}
