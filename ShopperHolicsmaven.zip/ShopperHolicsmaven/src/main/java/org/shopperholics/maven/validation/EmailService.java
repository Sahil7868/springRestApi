package org.shopperholics.maven.validation;

import javax.mail.MessagingException;

import org.springframework.stereotype.Repository;

@Repository("emailService")
public interface EmailService {

	public void sendmail(String email,String name) throws MessagingException;

}