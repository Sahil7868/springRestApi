package org.shopperholics.maven.service;

import java.util.List;

import org.shopperholics.maven.dao.ProductDao;
import org.shopperholics.maven.model.ProCat;
import org.shopperholics.maven.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

	ProductDao productDao;

	@Autowired
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	public List<ProCat> getProductList() {
		
		return productDao.getProductList();
	}

	public Product getProductListbyId(Integer pid) {
		return productDao.getProductListbyId(pid);
	}

	public Product addProduct(Product product) {
		return productDao.addProduct(product);
	}

	public Product updateProduct(Integer pid, Product product) {
		return productDao.updateProduct(pid, product);
	}

	public void deleteProduct(Integer pid) {
		productDao.deleteProduct(pid);
	}
}
