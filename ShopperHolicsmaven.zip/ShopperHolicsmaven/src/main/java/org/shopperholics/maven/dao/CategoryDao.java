package org.shopperholics.maven.dao;

import java.util.List;

import org.shopperholics.maven.model.Category;
import org.springframework.stereotype.Repository;;

@Repository("categoryDao")
public interface CategoryDao {

	public List<Category> getCategoryList();

	public Category getCategoryListbyId(Integer idcategory);

	public Category addCategory(Category category);

	public Category updateCategory(Integer idcategory, Category category);

	public void deleteCategory(Integer idcategory);

}
