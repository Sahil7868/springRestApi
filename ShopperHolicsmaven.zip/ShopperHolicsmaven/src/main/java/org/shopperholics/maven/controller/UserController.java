package org.shopperholics.maven.controller;

import java.util.List;
import java.util.regex.Pattern;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import org.shopperholics.maven.model.users;
import org.shopperholics.maven.service.UserService;
//import org.shopperholics.maven.validation.CrunchifyEmailTest;
import org.shopperholics.maven.validation.EmailService;
//import org.shopperholics.maven.validation.CrunchifyEmailTest;
import org.shopperholics.maven.validation.UserValidation;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private EmailService sendMail;

	@RequestMapping("/")
	@ResponseBody
	public String welcome() {
		return "Welcome to ShopperHolics.";
	}

	public static boolean isValid(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";

		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

	// URL:
	// http://localhost:8085/ShopperHolicsmaven/getallusers
	// http://localhost:8085/ShopperHolicsmaven/getallusers.xml
	// http://localhost:8085/ShopperHolicsmaven/getallusers.json
	@RequestMapping(value = "getallusers", //
			method = RequestMethod.GET, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<users> getUsers() {
		List<users> list = userService.getUserList();

		return list;
	}

	// URL:
	// http://localhost:8085/ShopperHolicsmaven/getUserById/{userId}
	// http://localhost:8085/ShopperHolicsmaven/getUserById/{userId}.xml
	// http://localhost:8085/ShopperHolicsmaven/getUserById/{userId}.json
	@RequestMapping(value = "/getUserById/{userId}", 
			method = RequestMethod.GET, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public users getUser(@PathVariable("userId") Integer userId) {
		return userService.getUserListbyId(userId);
	}

	// URL:
	// http://localhost:8080/ShopperHolicsmaven/addUser
	// http://localhost:8080/ShopperHolicsmaven/addUser.xml
	// http://localhost:8080/ShopperHolicsmaven/addUser.json
	@RequestMapping(value = "/addUser", //
			method = RequestMethod.POST, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })

	@ResponseBody
	public UserValidation addUser(@RequestBody users user) throws MessagingException {

		UserValidation data = new UserValidation();

		if (userService.IsExistEmail(user.getEmail())) {

			data.setEmailExist(true);
			data.setEmailCheck(false);
		} else {

			if (isValid(user.getEmail())) {

				users userdata = userService.addUser(user);

				data.setEmailCheck(false);
				data.setEmailExist(false);
				data.setUser(userdata);
				sendMail.sendmail(user.getEmail(), user.getFirstname());

			} else {
				data.setEmailCheck(true);
				data.setEmailExist(false);
			}
		}

		return data;

	}

	// URL:
	// http://localhost:8080/ShopperHolicsmaven/updateUser/{userId}
	// http://localhost:8080/ShopperHolicsmaven/updateUser/{userId}.xml
	// http://localhost:8080/ShopperHolicsmaven/updateUser/{userId}.json
	@RequestMapping(value = "/updateUser/{userId}", //
			method = RequestMethod.PUT, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public users updateUser(@PathVariable("userId") Integer userId, @RequestBody users user) {

		return userService.updateUser(userId, user);
	}

	// URL:
	// http://localhost:8080/ShopperHolicsmaven/deleteUser/{userId}
	@RequestMapping(value = "/deleteUser/{userId}", //
			method = RequestMethod.DELETE, //
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteUser(@PathVariable("userId") Integer userId) {
		userService.deleteUser(userId);
	}

}
