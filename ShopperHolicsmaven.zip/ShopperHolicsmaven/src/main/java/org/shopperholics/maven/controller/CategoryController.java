package org.shopperholics.maven.controller;

import java.util.List;

import org.shopperholics.maven.model.Category;
import org.shopperholics.maven.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	@RequestMapping(value = "getallcategory", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<Category> getCategories() {
		List<Category> list = categoryService.getCategoryList();

		return list;
	}

	@RequestMapping(value = "/getCategoryById/{idcategory}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Category getCategory(@PathVariable("idcategory") Integer idcategory) {
		return categoryService.getCategoryListbyId(idcategory);
	}

	@RequestMapping(value = "/addCategory", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })

	@ResponseBody
	public Category addCategory(@RequestBody Category category) {

		Category data = new Category();
		data = categoryService.addCategory(category);
		return data;

	}

	@RequestMapping(value = "/updateCategory/{idcategory}", method = RequestMethod.PUT, 
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public Category updateCategory(@PathVariable("idcategory") Integer idcategory, @RequestBody Category category) {

		return categoryService.updateCategory(idcategory, category);
	}

	@RequestMapping(value = "/deleteCategory/{idcategory}", method = RequestMethod.DELETE, 
			produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteCategory(@PathVariable("idcategory") Integer idcategory) {
		categoryService.deleteCategory(idcategory);
	}

}
