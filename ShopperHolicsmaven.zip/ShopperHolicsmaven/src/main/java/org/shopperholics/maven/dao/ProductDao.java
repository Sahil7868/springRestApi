package org.shopperholics.maven.dao;

import java.util.List;

import org.shopperholics.maven.model.Product;
import org.shopperholics.maven.model.ProCat;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public interface ProductDao {

	public List<ProCat> getProductList();

	public Product getProductListbyId(Integer pid);

	public Product addProduct(Product product);

	public Product updateProduct(Integer pid, Product product);

	public void deleteProduct(Integer pid);
	
}
