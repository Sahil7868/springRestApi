package org.shopperholics.maven.model;

//import java.sql.Timestamp;

public class users {

	private Integer usersid;
	private String email;
	private String firstname;
	private String lastname;
	private Integer active;
	private String password;
	private Integer role;

	// This default constructor is required if there are other constructors.
	public users() {

	}

	public users(Integer usersid, String email, String firstname, String lastname, Integer active, String password, Integer role) {

		this.usersid = usersid;
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
		this.active = active;
		this.password = password;
		this.role = role;

	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getUsersid() {
		return usersid;
	}

	public void setUsersid(Integer usersid) {
		this.usersid = usersid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Integer getActive() {
		return active;
	}

	public void setActive(Integer active) {
		this.active = active;
	}

}
