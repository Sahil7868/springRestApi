package org.shopperholics.maven.model;

public class Category {

	private Integer idcategory;
	private String categoryname;
	private String cat_Image;

	public String getCat_Image() {
		return cat_Image;
	}

	public void setCat_Image(String cat_Image) {
		this.cat_Image = cat_Image;
	}

	public Category() {
	}

	public Category(Integer idcategory, String categoryname, String cat_Image) {
		this.idcategory = idcategory;
		this.categoryname = categoryname;
		this.cat_Image = cat_Image; 
	}

	public Integer getIdcategory() {
		return idcategory;
	}

	public void setIdcategory(Integer idcategory) {
		this.idcategory = idcategory;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	
}
