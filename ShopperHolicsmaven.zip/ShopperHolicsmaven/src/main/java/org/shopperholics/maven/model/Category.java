package org.shopperholics.maven.model;

public class Category {

	private Integer idcategory;
	private String categoryname;

	public Category() {
	}

	public Category(Integer idcategory, String categoryname) {
		this.idcategory = idcategory;
		this.categoryname = categoryname;
	}

	public Integer getIdcategory() {
		return idcategory;
	}

	public void setIdcategory(Integer idcategory) {
		this.idcategory = idcategory;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	
}
