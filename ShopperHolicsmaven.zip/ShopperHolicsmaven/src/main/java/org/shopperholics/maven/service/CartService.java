package org.shopperholics.maven.service;

import java.util.List;

import org.shopperholics.maven.model.Cart;
import org.shopperholics.maven.model.ProCart;
import org.springframework.stereotype.Repository;

@Repository("cartService")
public interface CartService {

	
	public List<ProCart> getCartByEmail(String email);

	public Cart addCart(Cart cart);

	// public Category updateCategory(Integer idcategory, Category category);

	public void deleteCart(Integer cartId);

}
