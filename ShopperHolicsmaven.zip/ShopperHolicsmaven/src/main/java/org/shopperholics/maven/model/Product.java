

package org.shopperholics.maven.model;



public class Product {

	private Integer pid;
	private String sku;
	private String name;
	private String description;
	private Double regularprice;
	private Double discountprice;
	private Integer quantity;
	private Integer idcategory;

	public Product() {
	}

	public Product(Integer pid, String sku, String name, String description, Double regularprice, Double discountprice,
			Integer quantity, Integer idcategory) {

		this.pid = pid;
		this.sku = sku;
		this.name = name;
		this.description = description;
		this.regularprice = regularprice;
		this.discountprice = discountprice;
		this.quantity = quantity;
		this.idcategory = idcategory;

	}
	
	public Integer getIdcategory() {
		return idcategory;
	}

	public void setIdcategory(Integer idcategory) {
		this.idcategory = idcategory;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getRegularprice() {
		return regularprice;
	}

	public void setRegularprice(Double regularprice) {
		this.regularprice = regularprice;
	}

	public Double getDiscountprice() {
		return discountprice;
	}

	public void setDiscountprice(Double discountprice) {
		this.discountprice = discountprice;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}
