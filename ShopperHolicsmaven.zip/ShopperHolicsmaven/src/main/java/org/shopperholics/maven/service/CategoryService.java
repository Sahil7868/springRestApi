package org.shopperholics.maven.service;

import java.util.List;

import org.shopperholics.maven.model.Category;
import org.springframework.stereotype.Repository;

@Repository("categoryService")
public interface CategoryService {

	public List<Category> getCategoryList();

	public Category getCategoryListbyId(Integer idcategory);

	public Category addCategory(Category category);

	public Category updateCategory(Integer idcategory, Category category);

	public void deleteCategory(Integer idcategory);

}
