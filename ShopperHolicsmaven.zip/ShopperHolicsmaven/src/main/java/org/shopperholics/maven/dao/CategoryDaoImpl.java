package org.shopperholics.maven.dao;

import java.sql.Types;
import java.util.List;

import org.shopperholics.maven.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("categoryDao")
public class CategoryDaoImpl implements CategoryDao {

	@Autowired
	public JdbcTemplate jdbcTemplate;

	private static final String insertSql = "INSERT INTO  category (" + " idcategory, " + " categoryname, " + " cat_Image) "
			+ " VALUES(?,?,?) ";

	private static final String updateSql = "UPDATE category SET  categoryname = ?, cat_Image = ? WHERE idcategory = ?";

	private static final String deleteSql = "DELETE FROM category WHERE idcategory = ?";

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Category> getCategoryList() {
		String query = "SELECT * from category";
		List<Category> list = jdbcTemplate.query(query,

				new BeanPropertyRowMapper(Category.class));

		return list;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Category getCategoryListbyId(Integer idcategory) {
		String sql = "SELECT * FROM category WHERE idcategory = ?";

		Category data = (Category) jdbcTemplate.queryForObject(sql, new Object[] { idcategory },
				new BeanPropertyRowMapper(Category.class));

		return data;
	}

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public Category addCategory(Category category) {
		Object[] params = new Object[] { null, category.getCategoryname(), category.getCat_Image() };

		int[] types = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR };

		int row = jdbcTemplate.update(insertSql, params, types);

		String sql = "SELECT * FROM category ORDER BY idcategory desc limit 1";

		Category data = (Category) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(Category.class));

		return data;
	}

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public Category updateCategory(Integer idcategory, Category category) {
		Object[] params = new Object[] { category.getCategoryname(),  category.getCat_Image(), idcategory };

		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.INTEGER };

		int rows = jdbcTemplate.update(updateSql, params, types);

		String sql = "SELECT * FROM category WHERE idcategory = ?";

		Category data = (Category) jdbcTemplate.queryForObject(sql, new Object[] { idcategory },
				new BeanPropertyRowMapper(Category.class));

		return data;
	}

	@SuppressWarnings("unused")
	public void deleteCategory(Integer idcategory) {
		Object[] params = { idcategory };

		int[] types = { Types.INTEGER };

		int rows = jdbcTemplate.update(deleteSql, params, types);
	}

}
